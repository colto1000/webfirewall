# webfirewall
A proxy firewall with a web application admin frontend, written in Go.
